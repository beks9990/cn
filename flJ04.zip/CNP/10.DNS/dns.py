import socket
print 'welcome to DNS lookup'
URL=raw_input('enter URL:')
addr1=socket.gethostbyname(URL)
print addr1
IP=raw_input('enter IP address')
addr2=socket.gethostbyaddr(IP)
print addr2 
