import java.net.*;
import java.io.*;
import java.util.*;
public class ClientUDP 
{
	DatagramSocket dc;
	DatagramPacket dp;
	Scanner sc=new Scanner(System.in);
	
	
	ClientUDP()
	{
		try 
		{
			dc=new DatagramSocket();
			String str=new String("");
			while(true)
			{
			byte[] data=new  byte [1024];
			byte[] reciving=new byte[1024];
			System.out.println("Enter Your Message : ");
			str=sc.nextLine();
			data=str.getBytes();
			dp=new DatagramPacket(data,str.length(),InetAddress.getLocalHost(),3000);
			dc.send(dp);
			dc.receive(dp);
			String ss=new String(dp.getData(),0,dp.getLength());
			System.out.println("From: Server >>> "+ss);
			
			}
			
		} 
		catch (Exception e) 
		{
			System.out.println("Error  :  "+e);
		}
	}
	public static void main(String s[])
	{
		ClientUDP cs=new ClientUDP();
	}
}
