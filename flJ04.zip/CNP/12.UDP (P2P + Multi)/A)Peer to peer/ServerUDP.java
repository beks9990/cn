import java.net.*;
import java.io.*;
import java.util.*;
public class ServerUDP 
{
	DatagramSocket dc;
	DatagramPacket dp,dpp;

	Scanner sc=new Scanner(System.in);
	
	ServerUDP()
	{
		try
		{
				dc=new DatagramSocket(3000);
				while(true)
				{
					byte data[]=new byte[1024];
					byte send[]=new byte[1024];
					String str=new String("");
					dp=new DatagramPacket(data,1024);
					dc.receive(dp);
					String ss=new String(dp.getData());
					System.out.println("From : "+dp.getAddress()+" >>> "+ss);
					System.out.println("Enter Your Message : ");
					str=sc.nextLine();
					send=str.getBytes();
		dpp=new DatagramPacket(send,str.length(),dp.getAddress(),dp.getPort());
					dc.send(dpp);
				}
		}
		catch(Exception e)
		{
			System.out.println("Error     "+e);
		}
	}
	public static void main(String arg[])
	{
		ServerUDP sr=new ServerUDP();
	}
}
