import socket
import sys
s = socket.socket()
s.bind(("localhost",9999))
s.listen(10) 
i = 1
while True:
    sc, address = s.accept()
    print address
    f = open('2_'+ str(i)+".txt",'wb') #open in binary
    i=i+1
    while (True):
        l = sc.recv(1024)
        f.write(l)
        if not l:
            break
    f.close()
    sc.close()
    print('copied the file.')
s.close()


"""
saurabh@saurabh-HP-Laptop-15g-dr0xxx:~$ python TCP_File_Server.py
('127.0.0.1', 39422)
copied the file.
"""

