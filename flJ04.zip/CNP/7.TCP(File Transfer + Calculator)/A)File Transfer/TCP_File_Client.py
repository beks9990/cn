import socket
import sys
s = socket.socket()
s.connect(("localhost",9999))
f = open ("1_.txt", "rb")
l = f.read(1024)
while (l):
    s.send(l)
    l = f.read(1024)
s.close()

"""saurabh@saurabh-HP-Laptop-15g-dr0xxx:~$ python TCP_File_Client.py
saurabh@saurabh-HP-Laptop-15g-dr0xxx:~$ 
"""
