# Server.py file
# @author Adam Slattum
# @version 04/26/16
# References: https://docs.python.org/2/library/exceptions.html
import socket		 	 # Import socket module
import sys
s = socket.socket() 	  		 # Create a socket object
host = socket.gethostname()                    # Get local machine name
port = 6000
s.bind((host, port)) 			 # Bind to the port
s.listen(5) 			         # Now wait for client connection.
print("Server is up and running")
while True:
     c, addr = s.accept() 		# Establish connection with client.
     print('Got connection from', addr)
     while True:
          try:
               equation=c.recv(6000).decode()
               if equation == "Q" or equation == "q" or equation == "Quit" or equation == "quit" or equation == "quit()":
                    c.send("Quit".encode())
                    break
               else:
                    print("You gave me the equation:", equation)
                    result = eval(equation)
                    c.send(str(result).encode())
          except (ZeroDivisionError):
               c.send("ZeroDiv".encode())
          except (ArithmeticError):
               c.send("MathError".encode())
          except (SyntaxError):
               c.send("SyntaxError".encode())
          except (NameError):
               c.send("NameError".encode())
     c.close() 			# Close the connection.
"""
saurabh@saurabh-HP-Laptop-15g-dr0xxx:~$ python3 Calculator_Server.py
Server is up and running
Got connection from ('127.0.0.1', 51000)
You gave me the equation: add(1+1)
You gave me the equation: sub(1-1)
You gave me the equation: addition(1+1)
You gave me the equation: add:1+1
You gave me the equation: add:(1+1)
You gave me the equation: a(1+1)
You gave me the equation: addition:(1+1)
You gave me the equation: addition: 1+1
You gave me the equation: addition: (1+1)
You gave me the equation: (addition: 1+1)
You gave me the equation: (add: 1+1)
You gave me the equation: [1;2B
[1You gave me the equation: 6+6
You gave me the equation: 9*9
You gave me the equation: 6/2
You gave me the equation: 4-1
You gave me the equation: QUit
"""
