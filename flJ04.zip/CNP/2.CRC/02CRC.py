data = input('Enter data :')
generator = input('Enter generator :')
#data = '100100'
#generator = '1101'

generator_len = len(generator)                      # variable to store generator length
generator = int('0b' + generator, 2)                # convert generator to binary
frame = '0b' + data + '0' * (generator_len - 1)     # binary frame with appended zeros
dividend = int(frame[:2 + generator_len], 2)        # getting dividend for first operation

while len(frame) >= generator_len: 
    answer = dividend ^ generator
    frame = bin(answer) + frame[2 + generator_len:]
    dividend = int(frame[:2 + generator_len], 2)

Remainder = '0'*(generator_len-1 - (len(frame)-2)) + frame[2:] #data+no of zeros+remainder
print('Remainder :', Remainder)
print('CRC frame:', data + Remainder )


frame = input('Enter received frame :')
#frame = data + Remainder

dividend = int(frame[:2 + generator_len], 2)        # getting dividend for first operation
while len(frame) >= generator_len: 
    answer = dividend ^ generator
    frame = bin(answer) + frame[2 + generator_len:]
    dividend = int(frame[:2 + generator_len], 2)

Remainder = '0'*(generator_len-1 - (len(frame)-2)) + frame[2:] #data+no of zeros+remainder
print("Correct code received" if int(Remainder)==0 else "Incorrect code received")
