import socket
import sys

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

sock.bind(('localhost',23000))

sock.listen(1)

clisock, (ip,port) = sock.accept()

while True:    	
	data = clisock.recv(16)

	if "stop." in data:
		break
	else:			
		print "client: " + data
	
	data = raw_input("you: ")
	clisock.send(data)
	if "stop." in data:
		break
sock.close()
"""
saurabh@saurabh-HP-Laptop-15g-dr0xxx:~$ python pptcpserv.py
client: hi from client
you: hello
client: how are you
you: well
client: nice
you: stop
client: stop
you: stop.
saurabh@saurabh-HP-Laptop-15g-dr0xxx:~$ 

"""
